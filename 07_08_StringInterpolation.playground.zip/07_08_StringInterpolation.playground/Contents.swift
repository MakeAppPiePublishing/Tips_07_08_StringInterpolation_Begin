import UIKit

let size = 10
let price = 14.159265358

var str = "I'd Love a Margherita Pizza today"
print(str)

